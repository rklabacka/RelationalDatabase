//
//  Parameter.cpp
//  Lab_03_Relational Database
//
//  Created by Randy Klabacka on 3/22/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#include "Parameter.h"

string Parameter::getName() const {
    return param.getName();
}

tokenKind Parameter::getType() {
    return param.getType();
}