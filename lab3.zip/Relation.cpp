//
//  Relation.cpp
//  Lab_03_Relational Database
//
//  Created by Randy Klabacka on 3/22/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//
#include "Relation.h"
#include "Tuple.h"

#include "Parameter.h"
#include "Predicate.h"

#include <string>
#include <vector>

using namespace std;



void Relation::getHead(){
    cout << "(";
    if(rel_head.size()>0){
    for(int i = 0; i < rel_head.size() -1; i++){
        cout << rel_head[i].getName() << ",";
    }
    cout << rel_head[rel_head.size() -1].getName() << ")" << endl;
    }
}

vector<Parameter> Relation::getHeadVec(){
    return rel_head;
}

long int Relation::getNumTuples(){
    return rel_set.size();
}

/*void Relation::createStringVec(vector<Parameter> params_in){
    for(int i = 0; i < params_in.size(); ++i){
        rel_head.push_back(params_in[i].getName());
    }
}*/

void Relation::addToRelation(Tuple tup_in){
    rel_set.insert(tup_in);
}

void Relation::select(int i, string val){
    set<Tuple> tup_set;
    for(set<Tuple>::iterator it = rel_set.begin(); it != rel_set.cend(); ++it){
        if(it->getT(i) == val){
            tup_set.insert(*it);
        }
    }
    rel_set = tup_set;
}

void Relation::select(int i, int j){
    set<Tuple> tup_set;
    for(set<Tuple>::iterator it = rel_set.begin(); it != rel_set.cend(); ++it){
        if(it->getT(i) == it->getT(j)){
            tup_set.insert(*it);
        }
    }
    rel_set = tup_set;
}

void Relation::formatHead(int s){
    vector<Parameter> new_head;
    for(int i = 0; i < rel_head.size(); ++i){
        if(i != s){
            new_head.push_back(rel_head[i]);
        }
    }
    rel_head = new_head;
}

void Relation::formatTups(int s){
    set<Tuple> tup_set;
    for(set<Tuple>::iterator it = rel_set.begin(); it != rel_set.cend(); ++it) {
        Tuple t;
        for(int i = 0; i < it->size(); ++i){
            if(i != s){
                t.addToTuple(it->getT(i));
            }
        }
        tup_set.insert(t);
    }
    rel_set = tup_set;
}

void Relation::eraseHeadDups(vector<int>& v, vector<Parameter>& p){
    vector<Parameter> new_head;
    cout << "eraseHeadDups" << endl;
    cout << "\there's what the query needs to erase: " << endl;
    for(int i = 0; i < v.size(); ++i){
        cout << p[i].getName();
    }
    cout << "\n\tof the original query: " << endl;
    for(int i = 0; i < p.size(); ++i){
        cout << p[i].getName();
    }
    cout << "current head: "; getHead();
    cout << "head size: " << rel_head.size() << endl;
    for(int i = 0; i < rel_head.size(); ++i){
        for(int j = 0; j < v.size(); ++j){
            if(i != v[j] && i < v[j]){
                new_head.push_back(rel_head[i]);
            }
        }
    }
    rel_head = new_head;
    cout << "head size: " << rel_head.size() << endl;
    cout << "head after eraseHeadDups: "; getHead();
    cout << "head size: " << rel_head.size() << endl;
}

void Relation::renameHead(vector<Parameter>& p){
    vector<Parameter> new_head;
    for(int i = 0; i < p.size(); i++){
        new_head.push_back(p[i]);
    }
    rel_head = new_head;
}

void Relation::project(vector<Parameter>& p){
    set<Tuple> tup_set;
        for(set<Tuple>::iterator it = rel_set.begin(); it != rel_set.cend(); ++it){
            cout << "head size: " << rel_head.size() << endl;
            if(p.size() > 0){
            Tuple tup;
            for(int i = 0; i < it->size(); ++i){
                for(int j = 0; j < p.size(); ++j){
                    if(p[j].getType() == ID){
                        tup.addToTuple(it->getT(i));
                    }
                }
            }
            tup_set.insert(tup);
            }
        }
    rel_set = tup_set;
}

string Relation::getRelation(){
    string str = "";
    if(rel_head.size() > 0){
        str.append("\n");
    }
    for(std::set<Tuple>::iterator it = rel_set.begin(); it != rel_set.cend(); ++it){
        for(int i = 0; i < rel_head.size(); ++i){
            if(i == 0){
                str.append("  " + rel_head[i].getName() + "=" + it->getT(i));
            }
            else{
                str.append(" " + rel_head[i].getName() + "=" + it->getT(i));
            }
        }
        str.append("\n");
    }
    return str;
}

string Relation::getName() const{
    return rel_name;
}

Predicate Relation::getScheme(){
    return og_scheme;
}