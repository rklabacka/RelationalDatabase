//
//  Relation.h
//  Lab_03_Relational Database
//
//  Created by Randy Klabacka on 3/22/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_3__Relation__
#define __Lab_3__Relation__

#include <stdio.h>
#include <set>
#include <iostream>
#include <vector>
#include <string>

#include "Tuple.h"
#include "Scheme.h"
#include "Predicate.h"

#include "Parameter.h"

using namespace std;

class Relation
{
public:
    //CONSTRUCTOR
    Relation(Predicate scheme_in){
        og_scheme = scheme_in;
        rel_name = scheme_in.getName();
        rel_head = scheme_in.getParams();

    }
    Relation(){}
    //DESTRUCTOR
    ~Relation(){}
    
    //OPERATOR OVERLOAD
    friend bool operator ==(const Relation& R1, const Relation& R2)
    {
        if(R1.getName() == R2.getName()){
            return true;
        }
        else{
            return false;
        }
    }
    friend bool operator <(const Relation& R1, const Relation& R2)
    {
        if(R1.getName() < R2.getName()){
            return true;
        }
        else{
            return false;
        }
    }

    
    //GETTERS
    Predicate getScheme();
    string getName() const;
    void getHead();
    vector<Parameter> getHeadVec();
    string getRelation();
    long int getNumTuples();
    //SETTERS
    void addToRelation(Tuple tup_in);
    void formatHead(int s);
    void eraseHeadDups(vector<int>& v, vector<Parameter>& p);
    void formatTups(int s);
    void renameHead(vector<Parameter>& new_head);
    
    //SELECT
    void select(int i, string val);
    void select(int i, int j);
    //PROJECT
    void project(vector<Parameter>& p);
    //RENAME
    
private:
    string rel_name;
    vector<Parameter> rel_head;
    //******MAKE SURE YOU CHANGE THIS!!!!
    set<Tuple> rel_set;
    Predicate og_scheme;
};

#endif /* defined(__Lab_3__Relation__) */
