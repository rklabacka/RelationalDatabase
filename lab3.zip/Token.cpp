//
//  Token.cpp
//  Lab_03_Relational Database
//
//  Created by Randy Klabacka on 3/22/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#include "Token.h"

#include <sstream>
#include <string>
#include <stdio.h>
#include <iostream>

using namespace std;

//GETTERS
tokenKind Token::getType(){
    return token_type;
}


string Token::stringType(){
    cout << "\n\tgetType entered. Type = " << token_type << endl;
    stringstream ss;
    char c;
    ss << token_type;
    ss >> c;
    cout << "\tchar = " << c << endl;
    switch(c){
        case '0':
            return "COMMA";
        case '2':
            return "Q_MARK";
        case '3':
            return "LEFT_PAREN";
        case '4':
            return "RIGHT_PAREN";
        case '5':
            return "COLON";
        case '6':
            return "COLON_DASH";
        case '7':
            return "SCHEMES";
        case '8':
            return "FACTS";
        case '9':
            return "RULES";
        default:
            if(token_type == 10){
                return "QUERIES";
            }
            else if(token_type == 11){
                return "ID";
            }
            else if(token_type == 1){
                return "PERIOD";
            }
            else if(token_type == 12){
                return "STRING";
            }
            else{
                return "EoF";
            }
    }
}

string Token::getName() const{
    return name;
}
int Token::getLineNum(){
    return line_num;
}

//toString
string Token::toString(){
    //(TYPE,"name",line_num)
    stringstream ss;
    ss << line_num;
    string line_num_temp;
    ss >> line_num_temp;
    string string_ret = "(" + stringType() + ",\"" + name + "\"," + line_num_temp + ")";
    return string_ret;
}