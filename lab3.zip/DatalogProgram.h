//
//  DatalogProgram.h
//  Lab_03_Relational Database
//
//  Created by Randy Klabacka on 3/22/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_02_Parser__DatalogProgram__
#define __Lab_02_Parser__DatalogProgram__

#include <vector>
#include <stdio.h>
#include <map>
#include <sstream>
#include <algorithm>

#include "Relation.h"
#include "Tuple.h"

#include "Scanner.h"
#include "Token.h"
#include "Predicate.h"
#include "Parameter.h"
#include "Rule.h"

using namespace std;

class DatalogProgram
{
public:
    //Constructor
    DatalogProgram(vector<Token> tokenVectorIn)
    {
        vecPos = 0;
        scheme_index = 0;
        fact_index = 0;
        rule_index = 0;
        query_index = 0;
        domain_index = 0;
        
        cout << "DatalogProgram constructor entered" << endl;
        /* I don't know if I'm allowed to do this: */ tokenVectorParse = tokenVectorIn;}
    //Destructor
    ~DatalogProgram(){}
  
//DATABASER_________________________________________________________________________________________________________
    
    string schemeEvaluation();
    string factEvaluation();
    string queriesEvaluation();
    string queryEvaluation(Predicate query);
    map<Parameter,vector<int>> getParamMap(vector<Parameter> params);
    
    
    void predVecToString(vector<Predicate> vec);
    string paramVecToString(vector<Parameter> vec);
    string mapToString(map<Parameter,vector<int>>);
    string intVecToString(vector<int>);
    Relation findRelation(string q_name);
    void paramIsString(vector<Parameter>& p, int i, Relation& r);
    void paramIsID(vector<Parameter>& p, int i, Relation& r);
    bool YorN(Relation& r, string& str);
    void adjustHead(vector<Parameter>& p, Relation& r);
    void formatHead(vector<Parameter>& p, int s);
    bool isDuplicate(vector<Parameter>& p, int s);
    void eraseHeadStringsR(Relation& r);
    void eraseHeadDupsR(vector<int> v, vector<Parameter>& p, Relation& r);
    void renameHead(vector<Parameter>& p, Relation& r);
    
    void formatHeadQ(int j, vector<Parameter>& p);
    void eraseHeadDupsQ(vector<Parameter>&p, Relation& r);
    
//PARSER____________________________________________________________________________________________________________
    //Function for passing in vector
    void parse();
    //Recursive grammar functions
    void datalogProgram();
    void scheme();
    void schemeList();
    void fact();
    void factList();
    void rule();
    void ruleList();
    void query();
    void queryList();
    void predicate(vector<Predicate>& pred_vec);
    void predicateList(vector<Predicate>& pred_vec);
    void parameter(vector<Parameter>& param_vec);
    void parameterList(vector<Parameter>& param_vec);
    void epsilon();
    void checkeof();
    bool find(string find_string);
    string int_to_string(int int_index);
    void returnString(string& return_string, int index, vector<Predicate> vec);
    //match function
    void match(tokenKind);
    //alphabetize domains
    void alphabetize();
    
private:
    set<Relation> rel_set_empty;
    set<Relation> rel_set;
    
    int vecPos;
    int scheme_index;
    int fact_index;
    int rule_index;
    int query_index;
    int domain_index;
    
    vector<Token> tokenVectorParse;
    vector<Predicate> scheme_vec;
    vector<Predicate> fact_vec;
    vector<Rule> rule_vec;
    vector<Predicate> query_vec;
    vector<string> domain_vec;
    
};

#endif /* defined(__Lab_02_Parser__DatalogProgram__) */
