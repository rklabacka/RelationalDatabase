//
//  Scanner.cpp
//  Lab_03_Relational Database
//
//  Created by Randy Klabacka on 3/22/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#include <vector>
#include <istream>
#include <iostream>
#include <fstream>
#include <string>
#include <ctype.h>
#include <cctype>
#include <locale>
#include <sstream>

#include "Scanner.h"

using namespace std;

//readFile
vector<Token> Scanner::readFile(ifstream& inFile){
    //initialize variables
    char c;
    
    while(inFile.get(c)){
        switch(c){
            case ',':
                tokenVector.push_back(Token(COMMA, ",", line_count));
                //outFile << "(COMMA,\",\"," << intToString(line_count) << ")" << endl;
                token_count ++;
                break;
            case '.':
                tokenVector.push_back(Token(PERIOD, ".", line_count));
                //outFile << "(PERIOD,\".\"," << intToString(line_count) << ")" << endl;
                token_count ++;
                break;
            case '?':
                tokenVector.push_back(Token(Q_MARK, "?", line_count));
                //outFile << "(Q_MARK,\"?\"," << intToString(line_count) << ")" << endl;
                token_count ++;
                break;
            case '(':
                tokenVector.push_back(Token(LEFT_PAREN, "(", line_count));
                //outFile << "(LEFT_PAREN,\"(\"," << intToString(line_count) << ")" << endl;
                token_count ++;
                break;
            case ')':
                tokenVector.push_back(Token(RIGHT_PAREN, ")", line_count));
                //outFile << "(RIGHT_PAREN,\")\"," << intToString(line_count) << ")" << endl;
                token_count ++;
                break;
            case ':':
                whatKindOfColon(inFile, c);
                break;
            case '\'':
                stringTokenizer(inFile, c);
                break;
            default:
                defaultCase(inFile, c);
                break;
        }
    }
    
    tokenVector.push_back(Token(EoF, "\"\"", line_count));
    //outFile << "(EOF,\"\"," << intToString(line_count) << ")" << endl;
    token_count ++;
    //outFile << "Total Tokens = " << token_count;
    return tokenVector;
}

void Scanner::whatKindOfColon(ifstream& inFile, char c_current){
    char c_next = inFile.peek();
    if(c_next == '-'){
        inFile.get(c_next);
        tokenVector.push_back(Token(COLON_DASH, ":-", line_count));
        //outFile << "(COLON_DASH,\":-\"," << intToString(line_count) << ")" << endl;
        token_count ++;
    }
    else{
        tokenVector.push_back(Token(COLON, ":", line_count));
        //outFile << "(COLON,\":\"," << intToString(line_count) << ")" << endl;
        token_count ++;
    }
}

void Scanner::defaultCase(ifstream& inFile, char c){
    if(c == '\n'){
        line_count ++;
    }
    else if(c == '#'){
        inFile.get(c);
        while(c != '\n'){
            inFile.get(c);
        }
        line_count ++;
    }
    else if(isspace(c)){
    }
    else{
        otherStuff(inFile, c);
    }
}

void Scanner::stringTokenizer(ifstream& inFile, char c_current){
    char c = c_current;
    string ot_string = "";
    ot_string.push_back(c);
    inFile.get(c);
    while(c != '\''){
        if(c == '\n'){
            throw line_count;
        }
        ot_string.push_back(c);
        inFile.get(c);
    }
    ot_string.push_back(c);
    tokenVector.push_back(Token(STRING, ot_string, line_count));
    //outFile << "(STRING,\"" << ot_string << "\"," << intToString(line_count) << ")" << endl;
    
    token_count ++;
    
}

void Scanner::otherStuff(ifstream& inFile, char char_in){
    if(!isalpha(char_in)){
        notAlpha(inFile);
        throw line_count;
    }
    string ot_name = "";
    ot_name.push_back(char_in);
    char c = inFile.peek();
    while(isalnum(c)){
        inFile.get(c);
        if(!isalnum(c)){notAlpha(inFile); throw line_count;} //you need to look at the whole word!
        ot_name.push_back(c);
        c = inFile.peek();
    }
    whatIsItThen(ot_name);
}

void Scanner::notAlpha(ifstream& inFile){
    char c = 'c';
    inFile.get(c);
    while(!isspace(c)){
        inFile.get(c);
    }
}

void Scanner::whatIsItThen(string ot_name){
    if(ot_name == "Queries"){
        tokenVector.push_back(Token(QUERIES, "Queries", line_count));
        //outFile << "(QUERIES,\"Queries\"," << intToString(line_count) << ")" << endl;
        token_count ++;
    }
    else if(ot_name == "Facts"){
        tokenVector.push_back(Token(FACTS, "Facts", line_count));
        //outFile << "(FACTS,\"Facts\"," << intToString(line_count) << ")" << endl;
        token_count ++;
    }
    else if(ot_name == "Rules"){
        tokenVector.push_back(Token(RULES, "Rules", line_count));
        //outFile << "(RULES,\"Rules\"," << intToString(line_count) << ")" << endl;
        token_count ++;
    }
    else if(ot_name == "Schemes"){
        tokenVector.push_back(Token(SCHEMES, "Schemes", line_count));
        //outFile << "(SCHEMES,\"Schemes\"," << intToString(line_count) << ")" << endl;
        token_count ++;
    }
    else{
        tokenVector.push_back(Token(ID, ot_name, line_count));
        //outFile << "(ID,\"" << ot_name << "\"," << intToString(line_count) << ")" << endl;
        token_count ++;
    }
}

string Scanner::intToString(int line_count){
    stringstream s;
    s << line_count;
    string line_count_str;
    s >> line_count_str;
    return line_count_str;
}




