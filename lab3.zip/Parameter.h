//
//  Parameter.h
//  Lab_03_Relational Database
//
//  Created by Randy Klabacka on 3/22/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_02_Parser__Parameter__
#define __Lab_02_Parser__Parameter__

#include <stdio.h>
#include <string>
#include <vector>

#include "Token.h"

#include <vector>
#include <istream>
#include <iostream>
#include <fstream>
#include <string>
#include <ctype.h>
#include <cctype>
#include <locale>
#include <sstream>

//Schemes, Facts, & Queries should all be Predicate objects

//Where does the domain set go?
//Remember, these must be sorted before being added to the end of the output

class Parameter
{
public:
    //constructor
    Parameter(Token param_in){
        param = param_in;
    }
    Parameter(){}
    
    //getters
    string getName() const ;
    tokenKind getType();
    
    //operator overload
    friend bool operator ==(const Parameter& P1, const Parameter& P2)
    {
        if(P1.getName() == P2.getName()){
            return true;
        }
        else{
            return false;
        }
    }
    friend bool operator <(const Parameter& P1, const Parameter& P2)
    {
        if(P1.getName() < P2.getName()){
            return true;
        }
        else{
            return false;
        }
    }
    
private:
    Token param;
};

#endif /* defined(__Lab_02_Parser__Predicate__) */


/*
 Constructor should have:
 name of predicate [object] (should be ID)
 vector should contain the IDs
 */