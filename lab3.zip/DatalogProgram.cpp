//
//  DatalogProgram.cpp
//  Lab_03_Relational Database
//
//  Created by Randy Klabacka on 3/22/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#include "DatalogProgram.h"

//DATABASER_________________________________________________________________________________________________________
string DatalogProgram::schemeEvaluation(){
    string str = "Scheme Evaluation\n\n";
    for(int i = 0; i < scheme_vec.size(); ++i){
        rel_set_empty.insert(Relation(scheme_vec[i]));
    }
    return str;
}

string DatalogProgram::factEvaluation(){
    string str = "Fact Evaluation\n\n";
    for(set<Relation>::iterator it = rel_set_empty.begin(); it != rel_set_empty.cend(); ++it){
        Relation r = *it;
        for(int j = 0; j < fact_vec.size(); ++j){
            if(fact_vec[j].getName() == r.getName()){
                r.addToRelation(Tuple(fact_vec[j].getParams()));
            }
        }
        cout << r.getName() << r.getRelation() << r.getNumTuples() << endl;
        str.append(r.getName() + r.getRelation() + "\n");
        rel_set.insert(r);
    }
    return str;
}

string DatalogProgram::queriesEvaluation(){
    string str = "Query Evaluation\n";
    for(int i = 0; i < query_vec.size(); ++i){
        str.append(queryEvaluation(query_vec[i]));
    }
    return str;
}

string DatalogProgram::queryEvaluation(Predicate q){
    vector<Parameter> p = q.getParams();
    string q_name = q.getName();
    string str = "\n" + q.toString() + "?";
    Relation r = findRelation(q_name);
    cout << r.getName() << r.getRelation() << endl;
    vector<int> pos_ID_vec;
    vector<int> pos_STRING_vec;
    for(int i = 0; i < p.size(); ++i){
        if(p[i].getType() == STRING){
            paramIsString(p,i,r);
            pos_STRING_vec.push_back(i);
        }
        else if(p[i].getType() == ID){
            paramIsID(p,i,r);
            pos_ID_vec.push_back(i);
        }
    }
    if(YorN(r, str)){
        str.append("select" + r.getRelation());
        adjustHead(p,r);
        str.append("project" + r.getRelation());
        renameHead(p,r);
        str.append("rename" + r.getRelation());
    }
    return str;
}

Relation DatalogProgram::findRelation(string q_name){
    for(set<Relation>::iterator it = rel_set.begin(); it != rel_set.cend(); ++it){
        Relation r = *it;
        if(q_name == r.getName()){
            return r;
        }
    }
    return Relation(scheme_vec[0]);
}

void DatalogProgram::paramIsString(vector<Parameter>& p, int i, Relation& r){
    r.select(i, p[i].getName());
}

void DatalogProgram::paramIsID(vector<Parameter>& p, int i, Relation& r){
    for(int j = 0; j < p.size(); ++j){
        if(p[i] == p[j] && i != j && i < j){
            r.select(i,j);
        }
    }
}

bool DatalogProgram::YorN(Relation& r, string & str){
    string num_tup = int_to_string(r.getNumTuples());
    if(r.getNumTuples() > 0){
        str.append(" Yes(" + num_tup + ")\n");
        return true;
    }
    else{
        str.append(" No\n");
        return false;
    }
}

void DatalogProgram::adjustHead(vector<Parameter>& p, Relation& r){
    int repeat = 1;
    while(repeat == 1){
        repeat = 0;
        for(int i = 0; i < p.size(); ++i){
            if(p[i].getType() == ID){
                if(isDuplicate(p,i)) {
                    r.formatHead(i);
                    formatHead(p,i);
                    r.formatTups(i);
                    repeat = 1;
                    break;
                }
            }
            else if(p[i].getType() == STRING){
                r.formatHead(i);
                formatHead(p,i);
                r.formatTups(i);
                repeat = 1;
                break;
            }
        }
    }
}

void DatalogProgram::formatHead(vector<Parameter>& p, int s){
    vector<Parameter> new_head;
    for(int i = 0; i < p.size(); ++i){
        if(i != s){
            new_head.push_back(p[i]);
        }
    }
    p = new_head;
}

bool DatalogProgram::isDuplicate(vector<Parameter>& p, int s){
    for(int i = 0; i < p.size(); ++i){
        if(p[i] == p[s] && i < s){
            return true;
        }
    }
    return false;
}

void DatalogProgram::eraseHeadStringsR(Relation& r){
    //r.formatHead();
}

void DatalogProgram::eraseHeadDupsQ(vector<Parameter>&p, Relation& r){
    for(int i = 0; i < p.size(); ++i){
        for(int j = 0; j < p.size(); ++j){
            if(p[i] == p[j] && i != j){
                formatHeadQ(j,p);
            }
        }
    }
}

void DatalogProgram::formatHeadQ(int j, vector<Parameter>& p){
    vector<Parameter> new_head;
    for(int i = 0; i < p.size(); i++){
        if(i != j)
            new_head.push_back(p[i]);
    }
    p = new_head;
}


void DatalogProgram::eraseHeadDupsR(vector<int>v, vector<Parameter>&p, Relation& r){
    r.eraseHeadDups(v,p);
}

void DatalogProgram::renameHead(vector<Parameter>& p, Relation& r){
    vector<Parameter> new_head;
    for(int i = 0; i < p.size(); ++i){
        if(p[i].getType() == ID){
            new_head.push_back(p[i]);
        }
            
    }
    r.renameHead(new_head);
}

void DatalogProgram::predVecToString(vector<Predicate> pred_vec){
    for(int i = 0; i < pred_vec.size(); ++i){
        vector<Parameter> param_vec = pred_vec[i].getParams();
        for(int j = 0; j < param_vec.size(); ++j){
        }
    }
}


    

//Parser_______________________________________________________________________________________________________________________

void DatalogProgram::parse(){
    datalogProgram();
    predVecToString(scheme_vec);
}
void DatalogProgram::datalogProgram(){
    match(SCHEMES);match(COLON);scheme();schemeList();match(FACTS);match(COLON);factList();match(RULES);match(COLON);
    ruleList();match(QUERIES);match(COLON);query();queryList();checkeof();alphabetize();
}
void DatalogProgram::scheme(){
    predicate(scheme_vec);
    scheme_index ++;
    //should return vector of scheme predicate objects
}
void DatalogProgram::schemeList(){
    if(tokenVectorParse[vecPos].getType() == ID){
        scheme();schemeList();
    }
}
void DatalogProgram::factList(){
    if(tokenVectorParse[vecPos].getType() == ID){
        fact();factList();
    }
    return;
}
void DatalogProgram::fact(){
    predicate(fact_vec);
    //should return vector of fact predicate objects
    match(PERIOD);fact_index++;
}
void DatalogProgram::ruleList(){
    if(tokenVectorParse[vecPos].getType() == ID){
        rule();ruleList();
    }
}
void DatalogProgram::rule(){
    vector<Predicate> rule_head_vec;
    predicate(rule_head_vec);match(COLON_DASH);vector<Predicate> rule_body_vec;predicate(rule_body_vec);
    predicateList(rule_body_vec);match(PERIOD);rule_vec.push_back(Rule(rule_head_vec[0], rule_body_vec));rule_index++;
}
void DatalogProgram::query(){
    predicate(query_vec);match(Q_MARK);query_index++;
}
void DatalogProgram::queryList(){
    if(tokenVectorParse[vecPos].getType() == ID){
        query();queryList();
    }
}
void DatalogProgram::predicate(vector<Predicate>& pred_vec){
    match(ID);
    //begin creating predicate object by assigning ID to the parameter head
    string head = tokenVectorParse[vecPos - 1].getName();match(LEFT_PAREN);vector<Parameter> param_vec;
    parameter(param_vec);parameterList(param_vec);match(RIGHT_PAREN);pred_vec.push_back(Predicate(head, param_vec));
}
void DatalogProgram::predicateList(vector<Predicate>& pred_vec){
    if(tokenVectorParse[vecPos].getType() == COMMA){
        match(COMMA);
        predicate(pred_vec);
        predicateList(pred_vec);
    }
    return;
}
void DatalogProgram::parameterList(vector<Parameter>& param_vec){
    if(tokenVectorParse[vecPos].getType() == COMMA){
        match(COMMA);parameter(param_vec);parameterList(param_vec);
    }
    return;
}
void DatalogProgram::parameter(vector<Parameter>& param_vec){
    if(tokenVectorParse[vecPos].getType() == STRING){
        param_vec.push_back(Parameter(tokenVectorParse[vecPos]));match(STRING);
    }
    else if(tokenVectorParse[vecPos].getType() == ID){
        param_vec.push_back(tokenVectorParse[vecPos]);match(ID);
    }
    else{
        throw vecPos;
    }
}
void DatalogProgram::checkeof(){
}
bool DatalogProgram::find(string find_string){
    int i = 0;
    while(i != domain_index){
        if(domain_vec[i] == find_string){
            return true;
        }
        i ++;
    }
    return false;
}
string DatalogProgram::int_to_string(int int_index){
    stringstream ss;string string_index;ss << int_index;ss >> string_index;
    return string_index;
}
void DatalogProgram::match(tokenKind tokenType){
    if(tokenType == STRING){
        if(!find(tokenVectorParse[vecPos].getName())){
            domain_vec.push_back(tokenVectorParse[vecPos].getName());domain_index ++;
        }
    }
    if(tokenVectorParse[vecPos].getType() == tokenType){
        vecPos++;
    }
    else{
        throw vecPos;
    }
}
void DatalogProgram::returnString(string& return_string, int index, vector<Predicate> vec){
    if(index >0){
        for(int i = 0; i != index; i++){
            return_string.append("\n\t" + vec[i].toString());
        }
    }
}
void DatalogProgram::alphabetize(){
    sort( domain_vec.begin(), domain_vec.end() );
}