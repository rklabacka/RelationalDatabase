//
//  Scanner.h
//  Lab_01_Tokenizer
//
//  Created by Randy Klabacka on 1/26/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_01_Tokenizer__Scanner__
#define __Lab_01_Tokenizer__Scanner__

#include <stdio.h>
#include <vector>
#include <string>
#include <iostream>
#include <istream>
#include <iostream>
#include <fstream>

#include "Token.h"

using namespace std;

class Scanner
{
public:
    Scanner(){line_count = 1; token_count = 0; error = false;}
    ~Scanner(){}
    vector<Token> readFile(ifstream& inFileName);
    void otherStuff(ifstream& fileName, char c_in);
    void notAlpha(ifstream& fileName);
    void whatIsItThen(string string_in);
    void defaultCase(ifstream& fileName, char c);
    void whatKindOfColon(ifstream& fileName, char c_current);
    void stringTokenizer(ifstream& fileName, char c_current);
    string intToString(int line_count);

private:
    vector<Token> tokenVector;
    int token_count;
    int line_count;
    bool error;
};

#endif /* defined(__Lab_01_Tokenizer__Scanner__) */
