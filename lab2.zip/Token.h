//
//  Token.h
//  Lab_01_Tokenizer
//
//  Created by Randy Klabacka on 1/26/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_01_Tokenizer__Token__
#define __Lab_01_Tokenizer__Token__

#include <stdio.h>
#include <string>

using namespace std;

//enum [miniature objects]
enum tokenKind {
    COMMA, PERIOD, Q_MARK, LEFT_PAREN, RIGHT_PAREN, COLON, COLON_DASH, SCHEMES, FACTS, RULES, QUERIES, ID, STRING, EoF
    //list the possible tokens
};

//create class
class Token
{
public:
    //CONSTRUCTOR should contain type string and #
    Token(tokenKind type_in, string name_in, int line_num_in){
        token_type = type_in;
        name = name_in;
        line_num = line_num_in;
    }
    Token(){}
    
    //DESTRUCTOR
    ~Token(){};
    
    //GETTERS
    tokenKind getType();
    string stringType();
    string getName();
    int getLineNum();
    
    //toString
    string toString();
    
private:
    string name;
    int line_num;
    tokenKind token_type;
    
    
};

#endif /* defined(__Lab_01_Tokenizer__Token__) */
