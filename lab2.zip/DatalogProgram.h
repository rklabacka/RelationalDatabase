//
//  DatalogProgram.h
//  Lab_02_Parser
//
//  Created by Randy Klabacka on 2/2/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_02_Parser__DatalogProgram__
#define __Lab_02_Parser__DatalogProgram__

#include <vector>
#include <stdio.h>

#include "Scanner.h"
#include "Token.h"
#include "Predicate.h"
#include "Parameter.h"
#include "Rule.h"


class DatalogProgram
{
public:
    //Constructor
    DatalogProgram(vector<Token> tokenVectorIn)
    {
        vecPos = 0;
        scheme_index = 0;
        fact_index = 0;
        rule_index = 0;
        query_index = 0;
        domain_index = 0;
        
        cout << "DatalogProgram constructor entered" << endl;
    /* I don't know if I'm allowed to do this: */ tokenVectorParse = tokenVectorIn;}
    //Destructor
    ~DatalogProgram(){}
    
    //Function for passing in vector
    string parse();
    
    //Recursive grammar functions
    void datalogProgram();
    void scheme();
    void schemeList();
    void fact();
    void factList();
    void rule();
    void ruleList();
    void query();
    void queryList();
    void predicate(vector<Predicate>& pred_vec);
    void predicateList(vector<Predicate>& pred_vec);
    void parameter(vector<Parameter>& param_vec);
    void parameterList(vector<Parameter>& param_vec);
    void epsilon();
    void checkeof();
    bool find(string find_string);
    string int_to_string(int int_index);
    void returnString(string& return_string, int index, vector<Predicate> vec);
    
    
    //match function
    void match(tokenKind);
    
    //alphabetize domains
    void alphabetize();
    
private:
    int vecPos;
    int scheme_index;
    int fact_index;
    int rule_index;
    int query_index;
    int domain_index;
    
    vector<Token> tokenVectorParse;
    vector<Predicate> scheme_vec;
    vector<Predicate> fact_vec;
    vector<Rule> rule_vec;
    vector<Predicate> query_vec;
    vector<string> domain_vec;
    
};

#endif /* defined(__Lab_02_Parser__DatalogProgram__) */
