//
//  Predicate.cpp
//  Lab_02_Parser
//
//  Created by Randy Klabacka on 2/2/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#include "Predicate.h"

#include <vector>
#include <istream>
#include <iostream>
#include <fstream>
#include <string>
#include <ctype.h>
#include <cctype>
#include <locale>
#include <sstream>

string Predicate::getName(){
    return pred_name;
}

string Predicate::toString(){
    string return_string = "";
    return_string.append(getName() + "(");
    for(int i = 0; i < pred_params.size(); i++){
        return_string.append(pred_params[i].getName());
        if(i != (pred_params.size() - 1)){
            return_string.append(",");
        }
    }
    return_string.append(")");
    return return_string;
}