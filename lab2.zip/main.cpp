//
//  main.cpp
//  Lab_02_Parser
//
//  Created by Randy Klabacka on 2/2/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#include <iostream>
#include <vector>

#include "Scanner.h"
#include "Token.h"
#include "DatalogProgram.h"


/*
 Goal of Lab 2: return 4 vectors (Schemes, Facts, Rules, Queries)
*/

using namespace std;

int  main(int argc, const char * argv[]) {
    cout << "cout test" << endl;
    /*
     
     A good approach is to complete the project in three steps:
     First: write a parser that only checks syntax. (Does not build any data structures.)
     Second: write classes for data structures. (Rule, Predicate, Parameter, etc)
     Third: add code to the parser to create data structures. This can be done easily without modifying the lines of code that were created in the first step. For example when a parameter is being parsed a Parameter object is created and added to the current list of parameters stored in the Parser.
     */
    ifstream inFile;
    ofstream outFile;
    
    inFile.open(argv[1]);
    outFile.open(argv[2]);
    Scanner scanner;
    vector<Token> tokens = scanner.readFile(inFile);
    try{
        cout << "try entered" << endl;
        DatalogProgram parser(tokens);
        string results = parser.parse();
        outFile << results;

    }
    catch(int vecPos){
        string errorString = tokens[vecPos].toString();
        outFile << "Failure!\n  " << errorString;
    }
    


    return 0;
}
