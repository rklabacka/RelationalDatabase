//
//  Predicate.h
//  Lab_02_Parser
//
//  Created by Randy Klabacka on 2/2/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_02_Parser__Parameter__
#define __Lab_02_Parser__Parameter__

#include <stdio.h>
#include <string>
#include <vector>

#include "Token.h"

//Schemes, Facts, & Queries should all be Predicate objects

//Where does the domain set go?
//Remember, these must be sorted before being added to the end of the output

class Parameter
{
public:
    //constructor
    Parameter(Token param_in){
        param = param_in;
    }
    Parameter(){}
    
    //getters
    string getName();
    
private:
    Token param;
};

#endif /* defined(__Lab_02_Parser__Predicate__) */


/*
 Constructor should have:
 name of predicate [object] (should be ID)
 vector should contain the IDs
 */