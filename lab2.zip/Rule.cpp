//
//  Rule.cpp
//  Lab_02_Parser
//
//  Created by Randy Klabacka on 2/2/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#include "Rule.h"

#include <vector>
#include <istream>
#include <iostream>
#include <fstream>
#include <string>
#include <ctype.h>
#include <cctype>
#include <locale>
#include <sstream>

string Rule::toString(){
    string return_string = "";
    return_string.append(rule_head.toString() + " :- ");
    for(int i = 0; i < rule_body.size(); i++){
        return_string.append(rule_body[i].toString());
        if(i != (rule_body.size() - 1)){
            return_string.append(",");
        }
    }
    return return_string;
}
