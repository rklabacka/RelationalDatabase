//
//  Rule.h
//  Lab_02_Parser
//
//  Created by Randy Klabacka on 2/2/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_02_Parser__Rule__
#define __Lab_02_Parser__Rule__

#include <stdio.h>

#include "Token.h"
#include "Predicate.h"

class Rule
{
public:
    //constructor
    Rule(Predicate head_in, vector<Predicate> body_in){
        rule_head = head_in;
        rule_body = body_in;
    }
    
    string toString();
private:
    Predicate rule_head;
    vector<Predicate> rule_body;
};


#endif /* defined(__Lab_02_Parser__Rule__) */

//Rule object is composed by: Pred head will be the predicate on the left side, and pred body (vector of preds on the right)
