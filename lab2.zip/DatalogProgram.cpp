//
//  DatalogProgram.cpp
//  Lab_02_Parser
//
//  Created by Randy Klabacka on 2/2/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//
#include <vector>
#include <sstream>
#include <algorithm>

#include "DatalogProgram.h"
#include "Token.h"
#include "Scanner.h"
#include "Predicate.h"
#include "Parameter.h"
#include "Rule.h"

string DatalogProgram::parse(){
    cout << "PARSE" << endl;
    datalogProgram();
    string return_string = "";
    string scheme_str_index = int_to_string(scheme_index);
    string fact_str_index = int_to_string(fact_index);
    string rule_str_index = int_to_string(rule_index);
    string query_str_index = int_to_string(query_index);
    string domain_str_index = int_to_string(domain_index);
    return_string.append("Success!\nSchemes(" + scheme_str_index + "):");
    returnString(return_string, scheme_index, scheme_vec);
    return_string.append("\nFacts(" + fact_str_index + "):");
    returnString(return_string, fact_index, fact_vec);
    return_string.append("\nRules(" + rule_str_index + "):");
    if(rule_index > 0){
        for(int i = 0; i != rule_index; i++){
            return_string.append("\n\t" + rule_vec[i].toString());
        }
    }
    return_string.append("\nQueries(" + query_str_index + "):");
    returnString(return_string, query_index, query_vec);
    return_string.append("\nDomain(" + domain_str_index + "):");
    if(domain_index > 0){
        for(int i = 0; i < domain_vec.size(); i++){
            return_string.append("\n\t" + domain_vec[i]);
        }
    }
    return return_string;
}

void DatalogProgram::datalogProgram(){
    cout << "datalogProgram began" << endl;
    match(SCHEMES);
    match(COLON);
    scheme();
    schemeList();
    match(FACTS);
    match(COLON);
    factList();
    match(RULES);
    match(COLON);
    ruleList();
    match(QUERIES);
    match(COLON);
    query();
    queryList();
    checkeof();
    alphabetize();
}

void DatalogProgram::scheme(){
    predicate(scheme_vec);
    cout << "$$$SCHEME_VEC ADDITION$$$: " << scheme_vec[scheme_index].getName() << " added to scheme_vec" << endl;
    scheme_index ++;
    //should return vector of scheme predicate objects
}

void DatalogProgram::schemeList(){
    if(tokenVectorParse[vecPos].getType() == ID){
    scheme();
    schemeList();
    }
}

void DatalogProgram::factList(){
    if(tokenVectorParse[vecPos].getType() == ID){
    fact();
    factList();
    }
    return;
}

void DatalogProgram::fact(){
    predicate(fact_vec);
    //should return vector of fact predicate objects
    match(PERIOD);
    fact_index++;
}

void DatalogProgram::ruleList(){
    if(tokenVectorParse[vecPos].getType() == ID){
    rule();
    ruleList();
    }
}

void DatalogProgram::rule(){
    vector<Predicate> rule_head_vec;
    predicate(rule_head_vec);
    match(COLON_DASH);
    vector<Predicate> rule_body_vec;
    predicate(rule_body_vec);
    predicateList(rule_body_vec);
    match(PERIOD);
    rule_vec.push_back(Rule(rule_head_vec[0], rule_body_vec));
    rule_index++;
}

void DatalogProgram::query(){
    predicate(query_vec);
    match(Q_MARK);
    query_index++;
}

void DatalogProgram::queryList(){
    if(tokenVectorParse[vecPos].getType() == ID){
    query();
    queryList();
    }
}

void DatalogProgram::predicate(vector<Predicate>& pred_vec){
    match(ID);
    //begin creating predicate object by assigning ID to the parameter head
    string head = tokenVectorParse[vecPos - 1].getName();
    match(LEFT_PAREN);
    vector<Parameter> param_vec;
    parameter(param_vec);
    parameterList(param_vec);
    match(RIGHT_PAREN);
    cout << "WHAT YOU ARE PUSHING ONTO THE PREDICATE VECTOR: head: " << head << endl;
    pred_vec.push_back(Predicate(head, param_vec));
}

void DatalogProgram::predicateList(vector<Predicate>& pred_vec){
    if(tokenVectorParse[vecPos].getType() == COMMA){
    match(COMMA);
    predicate(pred_vec);
    predicateList(pred_vec);
    }
    return;
}

void DatalogProgram::parameterList(vector<Parameter>& param_vec){
    if(tokenVectorParse[vecPos].getType() == COMMA){
        match(COMMA);
        parameter(param_vec);
        parameterList(param_vec);
    }
    return;
}

void DatalogProgram::parameter(vector<Parameter>& param_vec){
    if(tokenVectorParse[vecPos].getType() == STRING){
        param_vec.push_back(Parameter(tokenVectorParse[vecPos]));
        match(STRING);
    }
    else if(tokenVectorParse[vecPos].getType() == ID){
        param_vec.push_back(tokenVectorParse[vecPos]);
        match(ID);
    }
    else{
        throw vecPos;
    }
}

void DatalogProgram::checkeof(){
    cout << "checkEoF entered" << endl;
    match(EoF);
}

bool DatalogProgram::find(string find_string){
    int i = 0;
    while(i != domain_index){
        if(domain_vec[i] == find_string){
            return true;
        }
        i ++;
    }
    return false;
}

string DatalogProgram::int_to_string(int int_index){
    stringstream ss;
    string string_index;
    ss << int_index;
    ss >> string_index;
    return string_index;
}


void DatalogProgram::match(tokenKind tokenType){
    cout << "***Match entered*** for type" << tokenType << "\n\tvecPos = " << vecPos << "\n\tvector[" << vecPos << "] = " << tokenVectorParse[vecPos].getName() << endl;
    if(tokenType == STRING){
        if(!find(tokenVectorParse[vecPos].getName())){
            domain_vec.push_back(tokenVectorParse[vecPos].getName());
            domain_index ++;
        }
    }
    if(tokenVectorParse[vecPos].getType() == tokenType){
        cout << "\ttoString function: " << tokenVectorParse[vecPos].toString() << endl;
        cout << "\tartificial toStri: " << tokenVectorParse[vecPos].getName() << "\n\ttype:\t" << tokenVectorParse[vecPos].stringType() << "\n\t line_num: " << tokenVectorParse[vecPos].getLineNum() << endl;
        vecPos++;
    }
    else{
        cout << "\tERROR" << endl;
        cout << tokenVectorParse[vecPos].toString();
        throw vecPos;
    }
}

void DatalogProgram::returnString(string& return_string, int index, vector<Predicate> vec){
    if(index >0){
        for(int i = 0; i != index; i++){
            return_string.append("\n\t" + vec[i].toString());
        }
    }
}

void DatalogProgram::alphabetize(){
    sort( domain_vec.begin(), domain_vec.end() );
}
