//
//  Parameter.cpp
//  Lab_02_Parser
//
//  Created by Randy Klabacka on 2/2/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#include "Parameter.h"

#include <vector>
#include <istream>
#include <iostream>
#include <fstream>
#include <string>
#include <ctype.h>
#include <cctype>
#include <locale>
#include <sstream>

string Parameter::getName(){
    return param.getName();
}