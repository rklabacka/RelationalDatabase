//
//  Token.cpp
//  Lab_01_Tokenizer
//
//  Created by Randy Klabacka on 1/26/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#include "Token.h"

//toString
string toString(){
    //(TYPE,"name",line_num)
    return "toString";
}