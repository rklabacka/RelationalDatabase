//
//  main.cpp
//  Lab_01_Tokenizer
//
//  Created by Randy Klabacka on 1/26/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#include <iostream>
#include <istream>
#include <iostream>
#include <fstream>

#include "Token.h"
#include "Scanner.h"

int main(int argc, const char * argv[]) {
    ifstream inFile;
    ofstream outFile;

    inFile.open(argv[1]);
    outFile.open(argv[2]);
    try{
    //have "readFile" function return a vector of tokens
    Scanner scanner;
    vector<Token> tokens = scanner.readFile(inFile, outFile);
    }
    catch(int line_num){
        cout << "**ERROR** line#" << line_num << endl;
        outFile << "Input error on line " << line_num;
    }
    
    //create a new scanner
    
    //create a vector<token> = 
    
    return 0;
}
