//
//  Scanner.cpp
//  Lab_01_Tokenizer
//
//  Created by Randy Klabacka on 1/26/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#include <vector>
#include <istream>
#include <iostream>
#include <fstream>
#include <string>
#include <ctype.h>
#include <cctype>
#include <locale>
#include <sstream>

#include "Scanner.h"

using namespace std;

//readFile
vector<Token> Scanner::readFile(ifstream& inFile, ofstream& outFile){
    //initialize variables
    char c;
    
    //get going
        cout << "file opened" << endl;
        while(inFile.get(c)){
            cout << "entered Klay" << endl;
            switch(c){
                case ',':
                    cout << "entered Dray. c = " << c << endl;
                    tokenVector.push_back(Token(COMMA, ",", line_count));
                    cout << "(COMMA,\",\"," << intToString(line_count) << ")" << endl;
                    outFile << "(COMMA,\",\"," << intToString(line_count) << ")" << endl;
                    token_count ++;
                    break;
                case '.':
                    cout << "entered Festus. c = " << c <<  endl;
                    tokenVector.push_back(Token(PERIOD, ".", line_count));
                    cout << "(PERIOD,\".\"," << intToString(line_count) << ")" << endl;
                    outFile << "(PERIOD,\".\"," << intToString(line_count) << ")" << endl;
                    token_count ++;
                    break;
                case '?':
                    cout << "entered Brazilian. c = " << c << endl;
                    tokenVector.push_back(Token(Q_MARK, "?", line_count));
                    cout << "(Q_MARK,\"?\"," << intToString(line_count) << ")" << endl;
                    outFile << "(Q_MARK,\"?\"," << intToString(line_count) << ")" << endl;
                    token_count ++;
                    break;
                case '(':
                    cout << "entered Falcon. c = " << c << endl;
                    tokenVector.push_back(Token(LEFT_PAREN, "(", line_count));
                    cout << "(LEFT_PAREN,\"(\"," << intToString(line_count) << ")" << endl;
                    outFile << "(LEFT_PAREN,\"(\"," << intToString(line_count) << ")" << endl;
                    token_count ++;
                    break;
                case ')':
                    cout << "entered Harrison. c = " << c << endl;
                    tokenVector.push_back(Token(RIGHT_PAREN, ")", line_count));
                    cout << "(RIGHT_PAREN,\")\"," << intToString(line_count) << ")" << endl;
                    outFile << "(RIGHT_PAREN,\")\"," << intToString(line_count) << ")" << endl;
                    token_count ++;
                    break;
                case ':':
                    cout << "entered Barbosa. c = " << c << endl;
                    whatKindOfColon(inFile, c, outFile);
                    break;
                case '\'':
                    cout << "entered Clark. c = " << c << endl;
                    stringTokenizer(inFile, c, outFile);
                    break;
                default:
                    cout << "entered Sdot. c = " << c << endl;
                    defaultCase(inFile, c, outFile);
                    break;
            }
        }
        
        tokenVector.push_back(Token(EoF, "\"\"", line_count));
        cout << "(EOF,\"\"," << intToString(line_count) << ")" << endl;
        outFile << "(EOF,\"\"," << intToString(line_count) << ")" << endl;
        token_count ++;
        outFile << "Total Tokens = " << token_count;
        return tokenVector;
}

void Scanner::whatKindOfColon(ifstream& inFile, char c_current, ofstream& outFile){
    char c_next = inFile.peek();
    if(c_next == '-'){
        inFile.get(c_next);
        cout << "entered :-" << endl;
        tokenVector.push_back(Token(COLON_DASH, ":-", line_count));
        cout << "(COLON_DASH,\":-\"," << intToString(line_count) << ")" << endl;
        outFile << "(COLON_DASH,\":-\"," << intToString(line_count) << ")" << endl;
        token_count ++;
    }
    else{
        cout << "entered :" << endl;
        tokenVector.push_back(Token(COLON, ":", line_count));
        cout << "(COLON,\":\"," << intToString(line_count) << ")" << endl;
        outFile << "(COLON,\":\"," << intToString(line_count) << ")" << endl;
        token_count ++;
    }
}

void Scanner::defaultCase(ifstream& inFile, char c, ofstream& outFile){
    cout << "entered DUB. c = " << c << endl;
    if(c == '\n'){
        line_count ++;
        cout << "Line count increment: hassei" << endl;
    }
    else if(c == '#'){
        inFile.get(c);
        while(c != '\n'){
            inFile.get(c);
        }
        line_count ++;
        cout << "Line count increment: whiteheadi" << endl;
    }
    else if(isspace(c)){
    }
    else{
        cout << "entered Steph" << endl;
        otherStuff(inFile, c, outFile);
    }
}

void Scanner::stringTokenizer(ifstream& inFile, char c_current, ofstream& outFile){
    char c = c_current;
    string ot_string = "";
    ot_string.push_back(c);
    inFile.get(c);
    while(c != '\''){
        if(c == '\n'){
            throw line_count;
        }
        ot_string.push_back(c);
        inFile.get(c);
    }
    ot_string.push_back(c);
    tokenVector.push_back(Token(STRING, ":", line_count));
    cout << "(STRING,\"" << ot_string << "\"," << intToString(line_count) << ")" << endl;
    outFile << "(STRING,\"" << ot_string << "\"," << intToString(line_count) << ")" << endl;

    token_count ++;

}

void Scanner::otherStuff(ifstream& inFile, char char_in, ofstream& outFile){
    cout << "entered Bogut. c = " << char_in << endl;
    if(!isalpha(char_in)){
        cout << "entered Harden" << endl;
        notAlpha(inFile);
        throw line_count;
    }
    string ot_name = "";
    ot_name.push_back(char_in);
    char c = inFile.peek();
    while(isalnum(c)){
        inFile.get(c);
        cout << "entered ChefC. c = " << c << endl;
        if(!isalnum(c)){notAlpha(inFile); throw line_count;} //you need to look at the whole word!
        ot_name.push_back(c);
        c = inFile.peek();
    }
    whatIsItThen(ot_name, line_count, outFile);
}

void Scanner::notAlpha(ifstream& inFile){
    char c = 'c';
    inFile.get(c);
    while(!isspace(c)){
        inFile.get(c);
    }
}

void Scanner::whatIsItThen(string ot_name, int line_count, ofstream& outFile){
    if(ot_name == "Queries"){
        tokenVector.push_back(Token(QUERIES, "Queries", line_count));
        cout << "(QUERIES,\"Queries\"," << intToString(line_count) << ")" << endl;
        outFile << "(QUERIES,\"Queries\"," << intToString(line_count) << ")" << endl;
        token_count ++;
    }
    else if(ot_name == "Facts"){
        tokenVector.push_back(Token(FACTS, "Facts", line_count));
        cout << "(FACTS,\"Facts\"," << intToString(line_count) << ")" << endl;
        outFile << "(FACTS,\"Facts\"," << intToString(line_count) << ")" << endl;
        token_count ++;
    }
    else if(ot_name == "Rules"){
        tokenVector.push_back(Token(RULES, "Rules", line_count));
        cout << "(RULES,\"Rules\"," << intToString(line_count) << ")" << endl;
        outFile << "(RULES,\"Rules\"," << intToString(line_count) << ")" << endl;
        token_count ++;
    }
    else if(ot_name == "Schemes"){
        tokenVector.push_back(Token(SCHEMES, "Schemes", line_count));
        cout << "(SCHEMES,\"Schemes\"," << intToString(line_count) << ")" << endl;
        outFile << "(SCHEMES,\"Schemes\"," << intToString(line_count) << ")" << endl;
        token_count ++;
    }
    else{
        tokenVector.push_back(Token(ID, ot_name, line_count));
        cout << "(ID,\"" << ot_name << "\"," << intToString(line_count) << ")" << endl;
        outFile << "(ID,\"" << ot_name << "\"," << intToString(line_count) << ")" << endl;
        token_count ++;
    }
}

string Scanner::intToString(int line_count){
    stringstream s;
    s << line_count;
    string line_count_str;
    s >> line_count_str;
    return line_count_str;
}




