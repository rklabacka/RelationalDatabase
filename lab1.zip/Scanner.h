//
//  Scanner.h
//  Lab_01_Tokenizer
//
//  Created by Randy Klabacka on 1/26/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_01_Tokenizer__Scanner__
#define __Lab_01_Tokenizer__Scanner__

#include <stdio.h>
#include <vector>
#include <string>
#include <iostream>
#include <istream>
#include <iostream>
#include <fstream>

#include "Token.h"

using namespace std;

class Scanner
{
public:
    Scanner(){line_count = 1; token_count = 0; error = false;}
    ~Scanner(){}
    vector<Token> readFile(ifstream& inFileName, ofstream& outFileName);
    void otherStuff(ifstream& fileName, char c_in, ofstream& outFile);
    void notAlpha(ifstream& fileName);
    void whatIsItThen(string string_in, int line_count, ofstream& outFile);
    void defaultCase(ifstream& fileName, char c, ofstream& outFile);
    void whatKindOfColon(ifstream& fileName, char c_current, ofstream& outFile);
    void stringTokenizer(ifstream& fileName, char c_current, ofstream& outFile);
    string intToString(int line_count);

private:
    vector<Token> tokenVector;
    int token_count;
    int line_count;
    bool error;
};

#endif /* defined(__Lab_01_Tokenizer__Scanner__) */
