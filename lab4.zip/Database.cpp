//
//  Database.cpp
//  Lab_3_RelationalDatabase
//
//  Created by Randy Klabacka on 3/22/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//
#include <string>

#include "Database.h"
#include "DatalogProgram.h"


void Database::addKeyValue(string str_in, Relation rel_in){
    db_map[str_in] = rel_in;
}
