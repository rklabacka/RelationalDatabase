//
//  Predicate.cpp
//  Lab_03_Relational Database
//
//  Created by Randy Klabacka on 3/22/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#include "Predicate.h"

#include <vector>
#include <istream>
#include <iostream>
#include <fstream>
#include <string>
#include <ctype.h>
#include <cctype>
#include <locale>
#include <sstream>

string Predicate::getName() const{
    return pred_name;
}

string Predicate::toString(){
    string return_string = "";
    return_string.append(getName() + "(");
    for(int i = 0; i < pred_params.size(); i++){
        return_string.append(pred_params[i].getName());
        if(i != (pred_params.size() - 1)){
            return_string.append(",");
        }
    }
    return_string.append(")");
    return return_string;
}

string Predicate::istring(int i){
    return pred_params[i].getName();
}

vector<Parameter> Predicate::getParams() const{
    return pred_params;
}