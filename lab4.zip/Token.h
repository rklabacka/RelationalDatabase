//
//  Token.h
//  Lab_03_Relational Database
//
//  Created by Randy Klabacka on 3/22/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_01_Tokenizer__Token__
#define __Lab_01_Tokenizer__Token__

#include <stdio.h>
#include <string>

using namespace std;

//enum [miniature objects]
enum tokenKind {
    COMMA, PERIOD, Q_MARK, LEFT_PAREN, RIGHT_PAREN, COLON, COLON_DASH, SCHEMES, FACTS, RULES, QUERIES, ID, STRING, EoF
    //list the possible tokens
};

//create class
class Token
{
public:
    //CONSTRUCTOR should contain type string and #
    Token(tokenKind type_in, string name_in, int line_num_in){
        token_type = type_in;
        name = name_in;
        line_num = line_num_in;
    }
    Token(){}
    
    //DESTRUCTOR
    ~Token(){};
    
    friend bool operator ==(const Token& T1, const Token& T2)
    {
        if(T1.getName() == T2.getName()){
            return true;
        }
        else{
            return false;
        }
    }
    friend bool operator <(const Token& T1, const Token& T2)
    {
        if(T1.getName() < T2.getName()){
            return true;
        }
        else{
            return false;
        }
    }
    
    //GETTERS
    tokenKind getType();
    string stringType();
    string getName() const;
    int getLineNum();
    
    //toString
    string toString();
    
private:
    string name;
    int line_num;
    tokenKind token_type;
    
    
};

#endif /* defined(__Lab_01_Tokenizer__Token__) */
