
//
//  Tuple.cpp
//  Lab_03_Relational Database
//
//  Created by Randy Klabacka on 3/22/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//
#include <string>
#include <iostream>

#include "Tuple.h"

//GETTERS
vector<string> Tuple::getTuple() const{
    return tup;
}

long int Tuple::size() const{
    return tup.size();
}

string Tuple::getT(int i) const{
    return tup[i];
}

string Tuple::toString() const{
    string ret_str = "";
    ret_str = "Tuple: (";
    for(int i = 0; i < tup.size(); ++i){
        ret_str.append(tup[i] + ",");
    }
        ret_str.append(")");
    return ret_str;
}

//SETTERS
void Tuple::createTuple(vector<Parameter> params_in){
    for(int i = 0; i < params_in.size(); ++i){
        tup.push_back(params_in[i].getName());
    }
}

void Tuple::addToTuple(string s){
    tup.push_back(s);
}
