//
//  Rule.cpp
//  Lab_03_Relational Database
//
//  Created by Randy Klabacka on 3/22/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#include "Rule.h"

#include <vector>
#include <istream>
#include <iostream>
#include <fstream>
#include <string>
#include <ctype.h>
#include <cctype>
#include <locale>
#include <sstream>

vector<Predicate> Rule::getBod() const{
    return body;
}

Predicate Rule::getHead() const{
    return head;
}

string Rule::toString(){
    string return_string = "";
    return_string.append(head.toString() + " :- ");
    for(int i = 0; i < body.size(); i++){
        return_string.append(body[i].toString());
        if(i != (body.size() - 1)){
            return_string.append(",");
        }
    }
    return_string.append("\n");
    return return_string;
}
