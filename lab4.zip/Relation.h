//
//  Relation.h
//  Lab_03_Relational Database
//
//  Created by Randy Klabacka on 3/22/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_3__Relation__
#define __Lab_3__Relation__

#include <stdio.h>
#include <set>
#include <iostream>
#include <vector>
#include <string>

#include "Tuple.h"
#include "Scheme.h"
#include "Predicate.h"

#include "Parameter.h"

using namespace std;

class Relation
{
public:
    //CONSTRUCTOR
    Relation(Predicate scheme_in){
        og_scheme = scheme_in;
        rel_name = scheme_in.getName();
        rel_head = scheme_in.getParams();

    }
    Relation(){}
    Relation(vector<Parameter> head_in){
        rel_head = head_in;
    }
    //DESTRUCTOR
    ~Relation(){}
    
    //OPERATOR OVERLOAD
    friend bool operator ==(const Relation& R1, const Relation& R2)
    {
        if(R1.getName() == R2.getName()){
            return true;
        }
        else{
            return false;
        }
    }
    friend bool operator <(const Relation& R1, const Relation& R2)
    {
        if(R1.getName() < R2.getName()){
            return true;
        }
        else{
            return false;
        }
    }

    
    //GETTERS
    Predicate getScheme();
    string getName() const;
    void getHead();
    vector<Parameter> getHeadVec();
    string getRelation();
    string getAdded();
    long int getNumTuples() const;
    long int getNumAdded() const;
    set<Tuple> getTuples() const;
    
    //SETTERS
    void addToRelation(Tuple tup_in);
    void formatHead(int s);
    void eraseHeadDups(vector<int>& v, vector<Parameter>& p);
    void formatTups(int s);
    //SELECT
    void select(int i, string val);
    void select(int i, int j);
    //PROJECT
    void project(vector<Parameter>& p);
    //RENAME
    void renameHead(vector<Parameter>& new_head);
    //JOIN
    Relation joinPrep(Relation& tj);
    vector<Parameter> combineHeads (vector<Parameter>& p, vector<pair<int,int>>& dup_vec);
    bool joinable(Tuple& ta, Tuple& tb, vector<pair<int,int>>& dup_vec);
    Tuple join(Tuple& ta, Tuple& tb, vector<pair<int,int>>& dup_vec);
    //UNION
    void ruleProject(vector<Parameter>& rh);
    set<Tuple> rel_union(set<Tuple>& tp, Relation& c);
    
private:
    string rel_name;
    vector<Parameter> rel_head;
    set<Tuple> rel_set;
    set<Tuple> rel_added;
    Predicate og_scheme;
};

#endif /* defined(__Lab_3__Relation__) */
