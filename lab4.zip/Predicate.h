//
//  Predicate.h
//  Lab_03_Relational Database
//
//  Created by Randy Klabacka on 3/22/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_02_Parser__Predicate__
#define __Lab_02_Parser__Predicate__

#include <stdio.h>
#include <string>
#include <vector>

#include "Token.h"
#include "Parameter.h"

//Schemes, Facts, & Queries should all be Predicate objects

//Where does the domain set go?
//Remember, these must be sorted before being added to the end of the output

class Predicate
{
public:
    //constructor
    Predicate(string ID_in, vector<Parameter> params_in){
        pred_name = ID_in;
        pred_params = params_in;
    }
    Predicate(){};
    
    //getters
    string getName() const;
    vector<Parameter> getParams() const;
    string toString();
    string istring(int i);
    
private:
    string pred_name;
    vector<Parameter> pred_params;
};

#endif /* defined(__Lab_02_Parser__Predicate__) */


/*
 Constructor should have:
 name of predicate [object] (should be ID)
 vector should contain the IDs
 */