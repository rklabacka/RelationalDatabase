//
//  Tuple.h
//  Lab_03_Relational Database
//
//  Created by Randy Klabacka on 3/22/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_3__Tuple__
#define __Lab_3__Tuple__

#include <stdio.h>
#include <vector>
#include <string>

#include "Parameter.h"

using namespace std;

class Tuple
{
public:
    //operator overload
    friend bool operator ==(const Tuple& T1, const Tuple& T2)
    {
        if(T1.getTuple() == T2.getTuple()){
            return true;
        }
        else{
            return false;
        }
    }
    friend bool operator <(const Tuple& T1, const Tuple& T2)
    {
        if(T1.getTuple() < T2.getTuple()){
            return true;
        }
        else{
            return false;
        }
    }

    //CONSTRUCTOR
    Tuple(vector<Parameter> params_in){
        createTuple(params_in);
    }
    Tuple(){
    }
    //GETTERS
    vector<string> getTuple() const;
    string getT(int i) const;
    string toString() const;
    long int size() const;
    //SETTERS
    void createTuple(vector<Parameter> params_in);
    void addToTuple(string s);
private:
    vector<string> tup;
};
#endif /* defined(__Lab_3__Tuple__) */
