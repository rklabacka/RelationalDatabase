//
//  Relation.cpp
//  Lab_03_Relational Database
//
//  Created by Randy Klabacka on 3/22/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//
#include "Relation.h"
#include "Tuple.h"

#include "Parameter.h"
#include "Predicate.h"

#include <string>
#include <vector>

using namespace std;





vector<Parameter> Relation::getHeadVec(){
    return rel_head;
}

set<Tuple> Relation::getTuples() const{
    return rel_set;
}

long int Relation::getNumTuples() const{
    return rel_set.size();
}

long int Relation::getNumAdded() const{
    return rel_added.size();
}

void Relation::addToRelation(Tuple tup_in){
    rel_set.insert(tup_in);
}

string Relation::getRelation(){
    string str = "";
    long int rh_size = rel_head.size();
    for(std::set<Tuple>::iterator it = rel_set.begin(); it != rel_set.cend(); ++it){
        for(int i = 0; i < rh_size; ++i){
            if(i == 0){
                str.append("  " + rel_head[i].getName() + "=" + it->getT(i));
            }
            else{
                str.append(" " + rel_head[i].getName() + "=" + it->getT(i));
            }
        }
        str.append("\n");
    }
    return str;
}

string Relation::getAdded(){
    string str = "";
    long int rh_size = rel_head.size();
    for(std::set<Tuple>::iterator it = rel_added.begin(); it != rel_added.cend(); ++it){
        for(int i = 0; i < rh_size; ++i){
            if(i == 0){
                str.append("  " + rel_head[i].getName() + "=" + it->getT(i));
            }
            else{
                str.append(" " + rel_head[i].getName() + "=" + it->getT(i));
            }
        }
        str.append("\n");
    }
    return str;
}

string Relation::getName() const{
    return rel_name;
}

Predicate Relation::getScheme(){
    return og_scheme;
}

void Relation::select(int i, string val){
    set<Tuple> tup_set;
    for(set<Tuple>::iterator it = rel_set.begin(); it != rel_set.cend(); ++it){
        if(it->getT(i) == val){
            tup_set.insert(*it);
        }
    }
    rel_set = tup_set;
}

void Relation::select(int i, int j){
    set<Tuple> tup_set;
    for(set<Tuple>::iterator it = rel_set.begin(); it != rel_set.cend(); ++it){
        if(it->getT(i) == it->getT(j)){
            tup_set.insert(*it);
        }
    }
    rel_set = tup_set;
}

void Relation::formatHead(int s){
    vector<Parameter> new_head;
    long int rh_size = rel_head.size();
    for(int i = 0; i < rh_size; ++i){
        if(i != s){
            new_head.push_back(rel_head[i]);
        }
    }
    rel_head = new_head;
}

void Relation::formatTups(int s){
    set<Tuple> tup_set;
    for(set<Tuple>::iterator it = rel_set.begin(); it != rel_set.cend(); ++it) {
        Tuple t;
        long int it_size = it->size();
        for(int i = 0; i < it_size; ++i){
            if(i != s){
                t.addToTuple(it->getT(i));
            }
        }
        tup_set.insert(t);
    }
    rel_set = tup_set;
}

void Relation::eraseHeadDups(vector<int>& v, vector<Parameter>& p){
    vector<Parameter> new_head;
    long int v_size = v.size();
    long int rh_size = rel_head.size();
    for(int i = 0; i < rh_size; ++i){
        for(int j = 0; j < v_size; ++j){
            if(i != v[j] && i < v[j]){
                new_head.push_back(rel_head[i]);
            }
        }
    }
    rel_head = new_head;
}

void Relation::renameHead(vector<Parameter>& p){
    rel_head = p;
}

void Relation::project(vector<Parameter>& p){
    set<Tuple> tup_set;
    for(set<Tuple>::iterator it = rel_set.begin(); it != rel_set.cend(); ++it){
        if(p.size() > 0){
            Tuple tup;
            for(int i = 0; i < it->size(); ++i){
                for(int j = 0; j < p.size(); ++j){
                    if(p[j].getType() == ID){
                        tup.addToTuple(it->getT(i));
                    }
                }
            }
            tup_set.insert(tup);
        }
    }
    rel_set = tup_set;
}

Relation Relation::joinPrep(Relation& tj){
    int joinablei = 0;
    vector<pair<int,int>> dup_vec;
    vector<Parameter> tjH = tj.getHeadVec();
    vector<Parameter> new_head = combineHeads(tjH, dup_vec);
    Relation r(new_head);
    for(set<Tuple>::iterator c_it = rel_set.begin(); c_it != rel_set.cend(); ++c_it){
        Tuple ta = *c_it;
        set<Tuple> tj_tups = tj.getTuples();
        for(set<Tuple>:: iterator tj_it = tj_tups.begin(); tj_it != tj_tups.cend(); ++tj_it){
            Tuple tb = *tj_it;
            if(joinable(ta, tb, dup_vec)){
                Tuple t = join(ta, tb, dup_vec);
                joinablei ++;
                r.addToRelation(t);
            }
        }
    }
    return r;
}

bool Relation::joinable(Tuple& ta, Tuple& tb, vector<pair<int,int>>& dup_vec){
    int flag = 0;
    for(int i = 0; i < dup_vec.size(); ++i){
        if(ta.getT(dup_vec[i].first) != tb.getT(dup_vec[i].second)){
            flag = 1;
        }
    }
    if(flag == 0){
        return true;
    }
    else{
        return false;
    }
}

Tuple Relation::join(Tuple& ta, Tuple& tb, vector<pair<int,int>>& dup_vec){
    Tuple t = ta;
    for(int i = 0; i < tb.size(); ++i){
        int flag = 0;
        for(int j = 0; j < dup_vec.size(); ++j){
            if(i == dup_vec[j].second){
                flag = 1;
            }
        }
        if(flag == 0){
            t.addToTuple(tb.getT(i));
        }
    }
    return t;
}

vector<Parameter> Relation::combineHeads(vector<Parameter>&tjH, vector<pair<int,int>>& dup_vec){
    vector<Parameter> new_head = rel_head;
    pair<int,int> dup_pair;
    long int tjsize = tjH.size();
    for(int i = 0; i < tjsize; ++i){
        int dups = 0;
        long int rhsize = rel_head.size();
        for (int j = 0; j < rhsize; ++j){
            if(rel_head[j] == tjH[i]){
                dup_pair = make_pair(j, i);
                dup_vec.push_back(dup_pair);
                dups = 1;
            }
        }
        if(dups == 0){
            new_head.push_back(tjH[i]);
        }
    }
    return new_head;
}

void Relation::ruleProject(vector<Parameter>& rh){
    set<Tuple> new_tuples;
    vector<int> vec_index;
    long int rh_size = rh.size();
    long int rel_head_size = rel_head.size();
    for(int i = 0; i < rh_size; ++i){
        for(int j = 0; j < rel_head_size; ++j){
            if(rh[i] == rel_head[j]){
                vec_index.push_back(j);
            }
        }
    }
    for(set<Tuple>::iterator it = rel_set.begin(); it != rel_set.cend(); ++it){
        Tuple t;
        long int vi_size = vec_index.size();
        for(int i = 0; i < vi_size; ++i){
            t.addToTuple(it->getT(vec_index[i]));
        }
        new_tuples.insert(t);
    }
    rel_head = rh;
    rel_set = new_tuples;
}

set<Tuple> Relation::rel_union(set<Tuple>& tp, Relation& c){
    int count = 0;
    set<Tuple> ctups = c.getTuples();
    set<Tuple> added;
    rel_added.clear();
    for(set<Tuple>::iterator it = ctups.begin(); it != ctups.cend(); ++it){
        Tuple t = *it;
        if(rel_set.count(t) == 0){
            rel_set.insert(t);
            added.insert(t);
        }
        count ++;
    }
    rel_added = added;
    return added;
}
