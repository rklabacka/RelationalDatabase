//
//  main.cpp
//  Lab_03
//
//  Created by Randy Klabacka on 2/2/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#include <iostream>
#include <vector>

#include "Scanner.h"
#include "Token.h"
#include "DatalogProgram.h"



using namespace std;

int  main(int argc, const char * argv[]) {
    ifstream inFile;
    ofstream outFile;
    
    inFile.open(argv[1]);
    outFile.open(argv[2]);
    Scanner scanner;
    vector<Token> tokens = scanner.readFile(inFile);
    try{
        DatalogProgram parser(tokens);
        parser.parse();
        outFile << parser.schemeEvaluation();
        outFile << parser.factEvaluation();
        outFile << parser.rulesEvaluation();
        outFile << parser.queriesEvaluation();
        
    }
    catch(int vecPos){
        string errorString = tokens[vecPos].toString();
        outFile << "Failure!\n  " << errorString;
    }
    
    
    
    return 0;
}
