//
//  Database.h
//  Lab_3_RelationalDatabase
//
//  Created by Randy Klabacka on 3/22/16.
//  Copyright (c) 2016 Randy Klabacka. All rights reserved.
//

#ifndef __Lab_3__Database__
#define __Lab_3__Database__

#include <stdio.h>
#include <string>
#include <map>

#include "Relation.h"
#include "DatalogProgram.h"

using namespace std;

class Database
{
public:
    Database(){}
    void addKeyValue(string str_in, Relation rel_in);
    void createRelations();
    
private:
    map<string, Relation> db_map;
};

#endif /* defined(__Lab_3__Database__) */
